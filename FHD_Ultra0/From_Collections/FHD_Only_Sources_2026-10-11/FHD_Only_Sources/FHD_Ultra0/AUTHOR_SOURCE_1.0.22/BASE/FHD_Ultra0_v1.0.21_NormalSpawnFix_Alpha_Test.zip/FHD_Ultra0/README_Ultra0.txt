FHD_Ultra0 1.0.21 Normal Spawn Fix Alpha — Test
Requires FHD_SET v2.4.14+
Based on 1.0.20 Missile Ammo 45% Penalty Alpha.
Runtime fix: removed unsupported GetGalaxyGenerationSeed from Normal shop spawn selection.
The destination shop is selected with vanilla Rnd(0,n-1), a function used by original game scripts/mod sources.
No balance changes: missile max-ammo penalty remains -45%, missile ammo consumption stays vanilla (1 charge per volley), and weapon wear remains 3% per volley.
Re-equip baseline preservation from 1.0.19 remains unchanged.
